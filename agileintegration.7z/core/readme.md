Contains the core application.

Start by building the parent folder with
~~~
mvn clean install
~~~

Then build this folder with the same command

Finally you can deploy all of the pieces with the features file provided. See the instructions in the readme in the folder above this for more instruction.
