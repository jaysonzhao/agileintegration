Contains custom beans used by the application during request processing

Processors typically deal with custom inline processing needs such as 
   - Transformers
   - Marshallers and UnMarshallers
   - Beans (Task specific, delegation friendly business code/logic).
   - Data Formatters   

NONE OF THESE ARE USED AT THE MOMENT!
