Contains configuration files for priming the Maven Repository with custom libraries and jars
