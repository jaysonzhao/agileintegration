Contains configuration files for Performance Testing
