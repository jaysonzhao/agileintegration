Contains configuration files for User Acceptance Tests
