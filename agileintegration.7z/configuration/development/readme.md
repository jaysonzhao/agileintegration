Contains configuration files for Development environments
