Contains configuration files for Custom Isolated configurations
