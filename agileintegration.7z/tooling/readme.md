Contains the Tooling, Custom plugins and Jars necessary to launch, manage and/or instrument the application.

~~~

For this demo, the only tooling you'll need is SoupUI. Install it and then load the project in this folder. There are two requests under the Match endpoint 'Match' and 'No Match', try sending both once the project is up.
